%=== EX_AOSMHeat===%
% example applying AOSM to the heat equation, to show its usefulness in
% time-dependent problems

% To fully show how AOSM works on time-dependent problems, we need to use
% an implicit discretization, ie. backward Euler.

% Re-use regimes:
%   [!] No re-use           _nul
%   [!] Saturated re-use    _sat
%   [x] Partial re-use
%   [x] Full re-use
% ITC regimes:
%   [x] Dirichlet
%   [!] Robin
% Methods:
%   [!] OSM                 _osm
%   [!] altAOSM             _alt
%   [!] paraAOSM            _par

clear

%---Problem parameters---%
dt=0.01;        % time step
nt=12;           % number of time steps
T=nt*dt;        % final time
N=100^2;        % total problem size
N1=49*100; N2=50*100;   % subdomain sizes
M=N-N1-N2;      % interface size
tol=1e-8;       % tolerance for error

%---Matrix---%
[A,ind,T1,T2]=MAT_AOSMTestSuite_Heat(N,N1,M,dt,0); % matrix of the problem

%---Initial conditions---%
u0=ones(N,1); u0(ind)=0;
ind1=1:N1+M; ind2=[N1+M+1:N,N1+(1:M)];
u10=u0(ind1); u20=u0(ind2);

%---Initializations---%
diff_alt_nul=zeros(1,nt);
diff_alt_sat=diff_alt_nul;
diff_par_nul=diff_alt_nul;
diff_par_sat=diff_alt_nul;
diff_osm    =diff_alt_nul;
it_alt_nul=diff_alt_nul;
it_alt_sat=diff_alt_nul;
it_par_nul=diff_alt_nul;
it_par_sat=diff_alt_nul;
it_osm    =diff_alt_nul;

%%
%---First step---%
u_control=A \ u0;
[u_alt_nul,T1_nul,T2_nul,err_alt_nul]=ALGO_faltAOSM_pc(A,N1,N2,u0,tol,M-1,T1,T2,u10);
[u_alt_sat,T1_alt,T2_alt,err_alt_sat]=ALGO_faltAOSM_pc(A,N1,N2,u0,tol,M-1,T1,T2,u10);
[u_par_nul,~,~,          err_par_nul]=ALGO_fparaAOSM_pc(A,N1,N2,u0,tol,M-1,T1,T2,u10,u20);
[u_par_sat,T1_par,T2_par,err_par_sat]=ALGO_fparaAOSM_pc(A,N1,N2,u0,tol,M-1,T1,T2,u10,u20);
[u_osm,~,~,err_osm]=ALGO_SM_pc(A,N1,N2,u0,tol,M-1,T1,T2);

diff_alt_nul(1)=norm(u_alt_nul - u_control);
diff_alt_sat(1)=norm(u_alt_sat - u_control);
diff_par_nul(1)=norm(u_par_nul - u_control);
diff_par_sat(1)=norm(u_par_sat - u_control);
diff_osm(1)    =norm(u_osm - u_control);
it_alt_nul(1)=length(err_alt_nul);
it_alt_sat(1)=length(err_alt_sat);
it_par_nul(1)=length(err_par_nul);
it_par_sat(1)=length(err_par_sat);
it_osm(1)    =length(err_osm);

figure(1)
subplot(2,3,1)
semilogy(1:length(err_alt_nul),err_alt_nul,'b.--',...
    1:length(err_alt_sat),err_alt_sat,'bo--',...
    1:length(err_par_nul),err_par_nul,'r*--',...
    1:length(err_par_sat),err_par_sat,'r^--',...
    1:length(err_osm),err_osm,'k-',...
    'linewidth',2,'markersize',10)
xlabel('Iteration')
ylabel('2-norm of error')
title(num2str(dt))
legend('altAOSM','altAOSM - Sat.','paraAOSM','paraAOSM - Sat.','OSM')
axis([1,M,1e-10,1])
set(gca,'fontsize',20,'linewidth',2)

for k=2:nt
    u_control=A \ u_control;

    [u_alt_nul,~,~,          err_alt_nul]=ALGO_faltAOSM_pc(A,N1,N2,u_alt_nul,tol,35,T1,T2,u_alt_nul(ind1));
    [u_alt_sat,T1_alt,T2_alt,err_alt_sat]=ALGO_faltAOSM_pc(A,N1,N2,u_alt_sat,tol,35,T1_alt,T2_alt,u_alt_sat(ind1));
    [u_par_nul,~,~,          err_par_nul]=ALGO_fparaAOSM_pc(A,N1,N2,u_par_nul,tol,35,T1,T2,u_par_nul(ind1),u_par_nul(ind2));
    [u_par_sat,T1_par,T2_par,err_par_sat]=ALGO_fparaAOSM_pc(A,N1,N2,u_par_sat,tol,35,T1_par,T2_par,u_par_sat(ind1),u_par_sat(ind2));
    [u_osm,~,~,err_osm]=ALGO_SM_pc(A,N1,N2,u_osm,tol,M-1,T1,T2,u_osm(ind1),u_osm(ind2));
    diff_alt_nul(k)=norm(u_control - u_alt_nul);
    diff_alt_sat(k)=norm(u_control - u_alt_sat);    
    diff_par_nul(k)=norm(u_control - u_par_nul);
    diff_par_sat(k)=norm(u_control - u_par_sat);
    diff_osm(k)    =norm(u_control - u_osm);
    it_alt_nul(k)=length(err_alt_nul);
    it_alt_sat(k)=length(err_alt_sat);
    it_par_nul(k)=length(err_par_nul);
    it_par_sat(k)=length(err_par_sat);
    it_osm(k)    =length(err_osm);

    if k<=6
        figure(1)
        subplot(2,3,mod(k-1,6)+1)
        semilogy(1:length(err_alt_nul),err_alt_nul,'b.--',...
            1:length(err_alt_sat),err_alt_sat,'bo--',...
            1:length(err_par_nul),err_par_nul,'r*--',...
            1:length(err_par_sat),err_par_sat,'r^--',...
            1:length(err_osm),err_osm,'k-',...
            'linewidth',2,'markersize',10)
        xlabel('Iteration')
        ylabel('2-norm of error')
        title(num2str(k*dt))
        axis([1,M,1e-10,1])
        set(gca,'fontsize',20,'linewidth',2)
    end
end

%%
figure(2)
semilogy(dt:dt:T,diff_alt_nul,'b.--', ...
    dt:dt:T,diff_alt_sat,'bo--',...
    dt:dt:T,diff_par_nul,'r*--',...
    dt:dt:T,diff_par_sat,'r^--', ...
    dt:dt:T,diff_osm,'k-',...
    'linewidth',2,'markersize',10)
xlabel('t')
ylabel('Difference between control and SMs')
legend('altAOSM','altAOSM - Sat.','paraAOSM','paraAOSM - Sat.','OSM')
set(gca,'fontsize',20,'linewidth',2)