function [A,ind,T1,T2]=MAT_AOSMTestSuite_Heat(N,N1,M,dt,type)
% generates the matrix and (0th order) optimized transmission conditions
% for the heat equation

[A,ind,T1,T2]=MAT_AOSMTestSuite_Laplace_v1_20230221(N);
A(ind,:)=0;
A=speye(N)-dt*A;

if type==2
    % Dirichlet
    T1=sparse(M,M); T2=sparse(M,M);
elseif type==1
    % Best, for some reason
    T1=speye(M)-dt*T1; T2=speye(M)-dt*T2;
else
    % OO0, from St-Cyr, Gander & Thomas, 2007
    Abb=A(N1+(1:M),N1+(1:M));  % central block, interface conditions
    h=2/(sqrt(N)-1);
    p=sqrt(pi/h^3) * ((pi/2)^2 + 1/dt)^(1/4);
    T1=-0.5*Abb + dt*p*speye(M);
    T1(1,:)=0; T1(end,:)=0; % avoid exterior BCs
    T2=T1;
end

end