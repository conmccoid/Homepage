%=== EX_AOSMConv===%
% example to compare convergence behaviour, using ALGO files as
% subfunctions

clear

%---Set-up---%
n=100; % number of points in each direction
N=n^2;
[A,ind,T1,T2]=MAT_AOSMTestSuite_Laplace_v1_20230221(N); % matrix of the problem
f=ones(N,1); f(ind)=1;  % RHS
u_control=A \ f;        % 'exact' solution

%---Red-Black set-up---%
y=ones(n,1);
n1=29; n2=19; n3=19; n4=30;
x1=[ ones(n1,1);0;zeros(n2,1);0; ones(n3,1);0;zeros(n4,1)];
x2=[zeros(n1,1);0; ones(n2,1);0;zeros(n3,1);0; ones(n4,1)];
bb=[zeros(n1,1);1;zeros(n2,1);1;zeros(n3,1);1;zeros(n4,1)];
Omega1=kron(x1,x2)+kron(x2,x1); Omega1=Omega1==1;
Omega2=kron(x1,x1)+kron(x2,x2); Omega2=Omega2==1;
Omegab=kron(bb,y)+kron(y,bb)+kron(bb,bb); Omegab=Omegab>=1;
A11=A(Omega1,Omega1); A1b=A(Omega1,Omegab); A12=A(Omega1,Omega2);
Abb=A(Omegab,Omegab); Ab1=A(Omegab,Omega1); Ab2=A(Omegab,Omega2);
A22=A(Omega2,Omega2); A2b=A(Omega2,Omegab); A21=A(Omega2,Omega1);
N1=nnz(Omega1); M=nnz(Omegab); N2=nnz(Omega2);
A=[A11,A1b,zeros(N1,N2);
    Ab1,Abb,Ab2;
    zeros(N2,N1),A2b,A22];
f=[f(Omega1);f(Omegab);f(Omega2)];
u_control=[u_control(Omega1);u_control(Omegab);u_control(Omega2)];

T1=kron(diag(bb),T1)+kron(T1,diag(bb)); T1(kron(bb,bb)==1,kron(bb,bb)==1)=0; T1=T1(Omegab,Omegab);
T2=kron(diag(bb),T2)+kron(T2,diag(bb)); T2(kron(bb,bb)==1,kron(bb,bb)==1)=0; T2=T2(Omegab,Omegab);
u10=zeros(N1+M,1); u20=zeros(N2+M,1);
% u10=rand(N1+M,1); u20=rand(N2+M,1);

%% ITCs: Robin
[u_alt,T1_alt,T2_alt,err_alt_R]=ALGO_faltAOSM_pc(A,N1,N2,f,eps,M-1,T1,T2,u10);
[u_par,T1_par,T2_par,err_par_R]=ALGO_fparaAOSM_pc(A,N1,N2,f,eps,M-1,T1,T2,u10,u20);
[u_osm, ~,~,err_osm]=ALGO_SM_pc(A,N1,N2,f,eps,M-1,T1,T2);

%% ITCs: Dirichlet
T1=sparse(M,M); T2=sparse(M,M);

[u_alt,T1_alt,T2_alt,err_alt_D]=ALGO_faltAOSM_pc(A,N1,N2,f,eps,M-1,T1,T2,u10);
[u_par,T1_par,T2_par,err_par_D]=ALGO_fparaAOSM_pc(A,N1,N2,f,eps,M-1,T1,T2,u10,u20);
% [u_sm, ~,~,err_sm]=ALGO_SM_pc(A,N1,N2,f,eps,M-1,T1,T2);

%% Presentation
figure(1)
semilogy(1:length(err_osm),err_osm,'k-',...
    1:length(err_alt_R),err_alt_R,'b.--',...
    1:length(err_alt_D),err_alt_D,'bo--',...
    1:length(err_par_R),err_par_R,'r*--',...
    1:length(err_par_D),err_par_D,'r^--',...
    'markersize',10,'linewidth',2)
xlabel('Iteration')
ylabel('2-norm of error')
legend('OSM','altAOSM - Robin','altAOSM - Dirichlet','paraAOSM - Robin','paraAOSM - Dirichlet')
axis([1,120,1e-15,1e5])
set(gca,'fontsize',20,'linewidth',2)

figure(2)
contourf(T1_alt)
colorbar
axis square