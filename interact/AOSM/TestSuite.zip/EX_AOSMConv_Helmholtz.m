%=== EX_AOSMConv_Helmholtz===%
% example to compare convergence behaviour, using ALGO files as
% subfunctions

clear

%---Set-up---%
n=100; % number of points in each direction
N=n^2;
h=2/(sqrt(N)-1);
k=2*pi / (10*h);
[A,ind]=MAT_AOSMTestSuite_Helmholtz(N,k^2); % matrix of the problem
f=ones(N,1); f(ind)=1;  % RHS
u_control=A \ f;        % 'exact' solution

N1=49*100; N2=50*100;   % subdomain sizes
M=N-N1-N2;      % interface size

u10=rand(N1+M,1); u20=rand(N2+M,1);

%% ITCs: Robin
% [u_alt,T1_alt,T2_alt,err_alt_R]=ALGO_faltAOSM_pc(A,N1,N2,f,eps,M-1,T1,T2,u10);
% [u_par,T1_par,T2_par,err_par_R]=ALGO_fparaAOSM_pc(A,N1,N2,f,eps,M-1,T1,T2,u10,u20);
% [u_osm, ~,~,err_osm]=ALGO_SM_pc(A,N1,N2,f,eps,M-1,T1,T2);

%% ITCs: Dirichlet
T1=sparse(M,M); T2=sparse(M,M);

[u_alt,T1_alt,T2_alt,err_alt_D]=ALGO_faltAOSM_pc(A,N1,N2,f,eps,M-1,T1,T2,u10);
[u_par,T1_par,T2_par,err_par_D]=ALGO_fparaAOSM_pc(A,N1,N2,f,eps,M-1,T1,T2,u10,u20);
[~,~,~,err_alt_gmr]=ALGO_faltGMRES(A,N1,N2,f,eps,M-1,T1,T2);
[~,~,~,err_par_gmr]=ALGO_fparaGMRES(A,N1,N2,f,eps,M-1,T1,T2);
[u_sm,~,~,err_sm]=ALGO_SM_pc(A,N1,N2,f,eps,M-1,T1,T2);

%% Presentation
figure(1)
semilogy(1:length(err_sm),err_sm,'k-',...
    2*(1:length(err_alt_gmr)),err_alt_gmr,'b.--',...
    1:length(err_par_gmr),err_par_gmr,'r*--',...
    1:length(err_alt_D),err_alt_D,'bo--',...
    1:length(err_par_D),err_par_D,'r^--',...
    'markersize',10,'linewidth',2)
xlabel('Iteration')
ylabel('2-norm of error')
legend('AS','MS w/ GMRES','AS w/ GMRES','altAOSM - Dirichlet','paraAOSM - Dirichlet')
axis([1,M,1e-15,1e5])
set(gca,'fontsize',20,'linewidth',2)