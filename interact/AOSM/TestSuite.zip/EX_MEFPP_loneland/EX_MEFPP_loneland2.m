% Loneland example with canals instead of channels
clear
close all

%===Data===%
Data=readstruct('loneland2.vtu',...
    'FileType','xml');
Data=Data.UnstructuredGrid.Piece; % remove VTK version header

%===Positions of nodes===%
Positions=Data.Points;
Positions=Positions.DataArray.Text;
Positions=sprintf('%s',Positions);
Positions=sscanf(Positions,'%g',[3,Inf]);
Positions=Positions([1,2],:);

%===T & K===%
TK=Data.PointData.DataArray;
[K,T]=TK.Text;
T=sscanf(sprintf('%s',T),'%g',[1,Inf]);
K=sscanf(sprintf('%s',K),'%g',[1,Inf]);

%===Connectivity===%
[Triangles,cells,types]=Data.Cells.DataArray.Text;
Triangles=sscanf(sprintf('%s',Triangles),'%g',[3,Inf])+1;

xPositions=Positions(1,:);
yPositions=Positions(2,:);

A_loneland2
b_loneland2
N=1095;
K(K==100)=1000;
tol=1e-8;
x_soln=A \ b;

% ind=(xPositions>0.5-0.05) & (xPositions<0.5+0.05);
% num=1:length(xPositions);
% figure
% patch(xPositions(Triangles),yPositions(Triangles),1)
% hold on
% for i=num(ind)
%     text(xPositions(i),yPositions(i),num2str(i))
% end
% hold off
%% Subdomains
indM=[271,1037,1085,1022,141,410,466,418,105,912,955,917,971,871,69,307,370,314,33,741,790,746,804,700,213,543,581,524,177,648,664,616,243];
xDomM=xPositions(indM); yDomM=yPositions(indM);
ind=1:N;
ind1=ind(xPositions<min(xDomM));
ind2=ind(xPositions>max(xDomM));
ind=setdiff(ind,[indM,ind1,ind2]);
while ~isempty(ind)
    k=ind(1); ind=ind(2:end);
    test=A(k,ind1)~=0;
    if sum(test)>0
        ind1=[ind1,k];
    else
        ind2=[k,ind2];
    end
end

xDom1=xPositions(ind1); yDom1=yPositions(ind1);
xDom2=xPositions(ind2); yDom2=yPositions(ind2);
xDomg=xPositions(indM); yDomg=yPositions(indM);
figure(1)
subplot(1,2,1)
patch(xPositions(Triangles),yPositions(Triangles),K(Triangles))
axis square
subplot(1,2,2)
hold on
scatter(xDom1,yDom1,'r.')
scatter(xDom2,yDom2,'b.')
scatter(xDomg,yDomg,'m*')
hold off
axis square

r=[ind1,indM,ind2];
N1=length(ind1); M=length(indM); N2=length(ind2);
Abb=A(indM,indM);  % central block, interface conditions
A=A(r,r); f=b(r);
Kb=K(indM);
%% First solves
p=0.67;
T1=-0.5*Abb + p*diag(Kb); T2=-0.5*Abb + p*diag(Kb);

u10=rand(N1+M,1); u20=rand(N2+M,1);
% u10=zeros(N1+M,1); u20=zeros(N2+M,1);
% u10=f(1:N1+M); u20=f([N1+M+1:N,N1+(1:M)]);

[~,~,~,error_OSM]=ALGO_SM_pc(A,N1,N2,f,tol,M-1,T1,T2);
[~,T1_alt_R,T2_alt_R,err_altO,test_R]=ALGO_faltAOSM_pc(A,N1,N2,f,tol,M-1,T1,T2,u10);
[~,T1_par_R,T2_par_R,err_parO]=ALGO_fparaAOSM_pc(A,N1,N2,f,tol,M-1,T1,T2,u10,u20);

T1=sparse(M,M); T2=T1;
[u_alt,T1_alt_D,T2_alt_D,err_alt,test_D]=ALGO_faltAOSM_pc(A,N1,N2,f,tol,M-1,T1,T2,u10);
[u_par,T1_par_D,T2_par_D,err_par]=ALGO_fparaAOSM_pc(A,N1,N2,f,tol,M-1,T1,T2,u10,u20);

%% Checking solutions
figure(4)
hold on
scatter3(xPositions(r),yPositions(r),u_alt,'b.')
scatter3(xPositions(r),yPositions(r),u_par,'r.')
scatter3(xPositions,yPositions,x_soln,'g*')
hold off
%% Presentation
figure(3)
semilogy(1:length(error_OSM),error_OSM,'k-',...
    1:length(err_alt),err_alt,'b.--',...
    1:length(err_par),err_par,'r*--',...
    1:length(err_altO),err_altO,'bo--',...
    1:length(err_parO),err_parO,'r^--',...
    'markersize',10,'linewidth',2)
xlabel('Iteration')
ylabel('2-norm of error')
legend('OSM','altAOSM - Dirichlet','paraAOSM - Dirichlet','altAOSM - Robin','paraAOSM - Robin')
axis([1,M,1e-15,1e5])
set(gca,'fontsize',20,'linewidth',2)