% Convert MEF++ .vtu files into MATLAB data

%===Complete collection of data===%
Data=readstruct('resultats_loneland.cont.vtu',...
    'FileType','xml');
Data=Data.UnstructuredGrid.Piece; % remove VTK version header

%===Positions of nodes===%
Positions=Data.Points;
Positions=Positions.DataArray.Text;
Positions=sprintf('%s',Positions);
Positions=sscanf(Positions,'%g',[3,Inf]);
Positions=Positions([1,2],:);

%===T & K===%
TK=Data.PointData.DataArray;
[K,T]=TK.Text;
T=sscanf(sprintf('%s',T),'%g',[1,Inf]);
K=sscanf(sprintf('%s',K),'%g',[1,Inf]);

%===Connectivity===%
[Triangles,cells,types]=Data.Cells.DataArray.Text;
Triangles=sscanf(sprintf('%s',Triangles),'%g',[3,Inf])+1;

xPositions=Positions(1,:);
yPositions=Positions(2,:);
% figure(1)
% subplot(1,2,1)
% patch(xPositions(Triangles),yPositions(Triangles),T(Triangles))
% title('Temperature')
% subplot(1,2,2)
% patch(xPositions(Triangles),yPositions(Triangles),K(Triangles))
% title('Conductivity')
% 
% figure
% plot3(xPositions,yPositions,1:length(xPositions),'.')