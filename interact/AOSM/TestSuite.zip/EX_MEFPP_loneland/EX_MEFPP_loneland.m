% EX_MEFPP_loneland
clear
close all

% can retrieve MEF++ solution using the Convert2Matlab file
conductivity=1000;
rhs=0;
Convert2Matlab_loneland
N=937; % matrix size: 937 x 937, 6213 non-zero

if conductivity==10
    A_10 % symmetric matrix
%     p=0.694;
elseif conductivity==100
    A_100
%     p=0.694;
elseif conductivity==1000
    A_1000
%     p=0.694;
elseif conductivity==10000
    A_10000
%     p=1;
elseif conductivity==1000000
    A_1000000
%     p=1;
end
K(K==100)=conductivity;

if rhs==0
    b_loneland % unit source, null BCs
elseif rhs==1
    b_BCs % unit BCs, null source
    b([1:4,17:52])=1; % add in BCs
elseif rhs==2
    b_SrcBCs % doesn't appear to be different from b_BCs, likely error in copy-paste
    b([1:4,17:52])=1; % add in BCs
elseif rhs==3
    b_quad
end

x_loneland % bunch of zeros for some reason

tol=1e-8; % error tolerance

%% Subdomains
indM=[21,717,523,623,142,344,300,338,116,922,492,789,506,788,469,919,90,...
    246,276,251,65,841,580,912,473,913,581,840,194,402,393,407,168,622,...
    457,716,39]; % handpicked interface
xDomM=xPositions(indM); yDomM=yPositions(indM);
ind=1:N;
ind1=ind(xPositions<min(xDomM));
ind2=ind(xPositions>max(xDomM));
ind=setdiff(ind,[indM,ind1,ind2]);
while ~isempty(ind)
    k=ind(1); ind=ind(2:end);
    test=A(k,ind1)~=0;
    if sum(test)>0
        ind1=[ind1,k];
    else
        ind2=[k,ind2];
    end
end

xDom1=xPositions(ind1); yDom1=yPositions(ind1);
xDom2=xPositions(ind2); yDom2=yPositions(ind2);
xDomg=xPositions(indM); yDomg=yPositions(indM);
figure(1)
subplot(1,2,1)
patch(xPositions(Triangles),yPositions(Triangles),K(Triangles))
axis square
subplot(1,2,2)
hold on
scatter(xDom1,yDom1,'r.')
scatter(xDom2,yDom2,'b.')
scatter(xDomg,yDomg,'m*')
hold off
axis square

r=[ind1,indM,ind2];
N1=length(ind1); M=length(indM); N2=length(ind2);
Abb=A(indM,indM);  % central block, interface conditions
A=A(r,r); f=b(r);
Kb=K(indM);
%% Reverse Cuthill-McKee
% r=symrcm(A);
% % w=bandwidth(A(r,r)); w=2*w+1;
% % M=round(w/2);
% M=45;
% N1=round((N-M)/2);
% N2=N-M-N1;
% 
% xDom1=xPositions(r(1:N1)); yDom1=yPositions(r(1:N1));
% xDom2=xPositions(r(N1+M+1:end)); yDom2=yPositions(r(N1+M+1:end));
% xDomg=xPositions(r(N1+(1:M))); yDomg=yPositions(r(N1+(1:M)));
% figure(2)
% hold on
% scatter(xDom1,yDom1,'r.')
% scatter(xDom2,yDom2,'b.')
% scatter(xDomg,yDomg,'m*')
% hold off
% 
% A=A(r,r); f=b(r);
% Abb=A(N1+(1:M),N1+(1:M));  % central block, interface conditions
% Kb=K(r); Kb=Kb(N1+(1:M));
%% First solves
p=0.67;
T1=-0.5*Abb + p*diag(Kb); T2=-0.5*Abb + p*diag(Kb);

u10=rand(N1+M,1); u20=rand(N2+M,1);
% u10=zeros(N1+M,1); u20=zeros(N2+M,1);
% u10=f(1:N1+M); u20=f([N1+M+1:N,N1+(1:M)]);

[~,~,~,error_OSM]=ALGO_SM_pc(A,N1,N2,f,tol,M-1,T1,T2);
[~,T1_alt_R,T2_alt_R,err_altO,test_R]=ALGO_faltAOSM_pc(A,N1,N2,f,tol,M-1,T1,T2,u10);
[~,T1_par_R,T2_par_R,err_parO]=ALGO_fparaAOSM_pc(A,N1,N2,f,tol,M-1,T1,T2,u10,u20);

T1=sparse(M,M); T2=T1;
[u_alt,T1_alt_D,T2_alt_D,err_alt,test_D]=ALGO_faltAOSM_pc(A,N1,N2,f,tol,M-1,T1,T2,u10);
[u_par,T1_par_D,T2_par_D,err_par]=ALGO_fparaAOSM_pc(A,N1,N2,f,tol,M-1,T1,T2,u10,u20);

%% Checking solutions
% figure(4)
% hold on
% scatter3(xPositions(r),yPositions(r),u_alt,'b.')
% scatter3(xPositions(r),yPositions(r),u_par,'r.')
% scatter3(xPositions,yPositions,x_soln,'g*')
% hold off
%% Presentation
figure(3)
semilogy(1:length(error_OSM),error_OSM,'k-',...
    1:length(err_alt),err_alt,'b.--',...
    1:length(err_par),err_par,'r*--',...
    1:length(err_altO),err_altO,'bo--',...
    1:length(err_parO),err_parO,'r^--',...
    'markersize',10,'linewidth',2)
xlabel('Iteration')
ylabel('2-norm of error')
legend('OSM','altAOSM - Dirichlet','paraAOSM - Dirichlet','altAOSM - Robin','paraAOSM - Robin')
axis([1,M,1e-10,1e5])
set(gca,'fontsize',20,'linewidth',2)

%% Re-use: unit BCs, null source
b_BCs % unit BCs, null source
b([1:4,17:52])=1; % add in BCs
f=b(r);

[~,~,~,error_OSM_alt_R]=ALGO_SM_pc(A,N1,N2,f,tol,M-1,T1_alt_R,T2_alt_R);
[~,~,~,error_OSM_par_R]=ALGO_SM_pc(A,N1,N2,f,tol,M-1,T1_par_R,T2_par_R);
[~,~,~,error_OSM_alt_D]=ALGO_SM_pc(A,N1,N2,f,tol,M-1,T1_alt_D,T2_alt_D);
[~,~,~,error_OSM_par_D]=ALGO_SM_pc(A,N1,N2,f,tol,M-1,T1_par_D,T2_par_D);
[~,~,~,err_altO]=ALGO_faltAOSM_pc(A,N1,N2,f,tol,M-1,T1_alt_R,T2_alt_R,u10);
[~,~,~,err_parO]=ALGO_fparaAOSM_pc(A,N1,N2,f,tol,M-1,T1_par_R,T2_par_R,u10,u20);
[~,~,~,err_alt]=ALGO_faltAOSM_pc(A,N1,N2,f,tol,M-1,T1_alt_D,T2_alt_D,u10);
[~,~,~,err_par]=ALGO_fparaAOSM_pc(A,N1,N2,f,tol,M-1,T1_par_D,T2_par_D,u10,u20);

figure(4)
semilogy(1:length(error_OSM_alt_R),error_OSM_alt_R,'k.--',...
    1:length(error_OSM_par_R),error_OSM_par_R,'ko--',...
    1:length(error_OSM_alt_D),error_OSM_alt_D,'k*--',...
    1:length(error_OSM_par_D),error_OSM_par_D,'k^--',...
    1:length(err_alt),err_alt,'b.--',...
    1:length(err_par),err_par,'r.--',...
    1:length(err_altO),err_altO,'bo--',...
    1:length(err_parO),err_parO,'ro--',...
    'markersize',10,'linewidth',2)
xlabel('Iteration')
ylabel('2-norm of error')
legend('OSM - alt Robin','OSM - para Robin','OSM - alt Dirichlet','OSM - para Dirichlet','altAOSM - Dirichlet','paraAOSM - Dirichlet','altAOSM - Robin','paraAOSM - Robin')
axis([1,M,1e-15,1e5])
set(gca,'fontsize',20,'linewidth',2)
%% Re-use: quadratic source, null BCs
b_quad
b([1:4,17:52])=1; % add in BCs
f=b(r);

T1=-0.5*Abb + p*diag(Kb); T2=-0.5*Abb + p*diag(Kb);
[~,~,~,error_OSM]=ALGO_SM_pc(      A,N1,N2,f,tol,M-1,T1,T2);
[~,~,~,error_OSM_alt_R]=ALGO_SM_pc(A,N1,N2,f,tol,M-1,T1_alt_R,T2_alt_R);
[~,~,~,error_OSM_par_R]=ALGO_SM_pc(A,N1,N2,f,tol,M-1,T1_par_R,T2_par_R);
[~,~,~,error_OSM_alt_D]=ALGO_SM_pc(A,N1,N2,f,tol,M-1,T1_alt_D,T2_alt_D);
[~,~,~,error_OSM_par_D]=ALGO_SM_pc(A,N1,N2,f,tol,M-1,T1_par_D,T2_par_D);
[~,~,~,err_altO]=ALGO_faltAOSM_pc(A,N1,N2,f,tol,M-1,T1_alt_R,T2_alt_R,u10);
[~,~,~,err_parO]=ALGO_fparaAOSM_pc(A,N1,N2,f,tol,M-1,T1_par_R,T2_par_R,u10,u20);
[~,~,~,err_alt]=ALGO_faltAOSM_pc(A,N1,N2,f,tol,M-1,T1_alt_D,T2_alt_D,u10);
[~,~,~,err_par]=ALGO_fparaAOSM_pc(A,N1,N2,f,tol,M-1,T1_par_D,T2_par_D,u10,u20);

figure(5)
subplot(1,2,1)
semilogy(1:length(error_OSM),error_OSM','k-',...
    1:length(error_OSM_alt_R),error_OSM_alt_R,'k.--',...
    1:length(error_OSM_par_R),error_OSM_par_R,'ko--',...
    1:length(error_OSM_alt_D),error_OSM_alt_D,'k*--',...
    1:length(error_OSM_par_D),error_OSM_par_D,'k^--',...
    'markersize',10,'linewidth',2)
xlabel('Iteration')
ylabel('2-norm of error')
legend('Original','alt w/ Robin','para w/ Robin','alt w/ Dirichlet','para w/ Dirichlet')
axis([1,M,1e-10,1e5])
set(gca,'fontsize',20,'linewidth',2)
subplot(1,2,2)
semilogy(1:length(err_altO),err_altO,'b.--',...
    1:length(err_parO),err_parO,'ro--',...
    1:length(err_alt),err_alt,'b*--',...
    1:length(err_par),err_par,'r^--',...
    'markersize',10,'linewidth',2)
xlabel('Iteration')
ylabel('2-norm of error')
legend('altAOSM - Robin','paraAOSM - Robin','altAOSM - Dirichlet','paraAOSM - Dirichlet')
axis([1,M,1e-10,1e5])
set(gca,'fontsize',20,'linewidth',2)