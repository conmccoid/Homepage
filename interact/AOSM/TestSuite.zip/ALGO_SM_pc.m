function [u,T1,T2,error] = ALGO_SM_pc(A,N1,N2,f,tol,itermax,T1,T2,u10,u20)
% SM_pc runs a Schwarz method in a predictor-corrector formulation

%===Problem setup: constant components===%
N=length(A);    % size of full system
M=N-N1-N2;      % size of transmission boundary
%---Matrix blocks---% (b is for boundary)
A11=A(1:N1,1:N1);      % top left block, interior of 1st subdomain
A1b=A(1:N1,N1+1:N1+M); % top middle block, boundary contribution 
A10=A(1:N1,N1+M+1:end);% top right block, ideally zero
Ab1=A(N1+(1:M),1:N1);      % middle left block, 1st domain on boundary
Abb=A(N1+(1:M),N1+(1:M));  % central block, interface conditions
Ab2=A(N1+(1:M),N1+M+1:end);% middle right block, 2nd domain on boundary
A22=A(N1+M+1:end,N1+M+1:end);% bottom right block, int of 2nd subdomain
A2b=A(N1+M+1:end,N1+(1:M));  % bottom middle block, boundary contribution
A20=A(N1+M+1:end,1:N1);      % bottom left block, ideally zero
if nnz(A10)>0 || nnz(A20)>0 % checking appropriate zeros in subdivision
    disp('Subdivision not allowed: nonzero elements in corner blocks')
end
f1=f(1:N1); fb=f(N1+(1:M)); f2=f(N1+M+1:end);               % RHS, constant parts

%===Initialization: first choices of u's and T's===%
%---u's---%
if nargin<=8
    u10=rand(N1+M,1); u20=rand(N2+M,1);
end
u11=u10(1:N1);           % solution on 1st subdomain
u1b=u10(N1+1:end);       % solution on interface of 1st subdomain
u22=u20(1:N2);           % solution on 2nd subdomain
u2b=u20(N2+1:end);       % solution on interface of 2nd subdomain
%---A's---%
A1=[A11,A1b;Ab1,Abb+T2]; A2=[A22,A2b;Ab2,Abb+T1]; % subdomain matrices

%---First run---%
z1 = -Ab1*u11 + T1*u1b;
z2 = -Ab2*u22 + T2*u2b;
u1 = A1 \ [f1;fb+z2];
u2 = A2 \ [f2;fb+z1];
d1 = u1 - u10; % difference in iterates between generations
d2 = u2 - u20;
d11= d1(1:N1);
d22= d2(1:N2);
d1b= d1(N1+1:end);
d2b= d2(N2+1:end);
z1 = -Ab1*d11 + T1*d1b;
z2 = -Ab2*d22 + T2*d2b;

%---Update previous solutions---%
u11= u1(1:N1);      % new solution in 1st subdomain, etc.
u1b= u1(N1+1:end);
u22= u2(1:N2);
u2b= u2(N2+1:end);

%---iteration count---%
iter=0; iter_total=1;

%~~~Convergence behaviour~~~%
u_control = A \ f;
error=norm(u_control - [u11; (u1b+u2b)/2; u22]);
%~~~%

%===Iterations===%
while norm(d1)+norm(d2)>tol && iter_total<=itermax
    d1 = A1 \ [sparse(N1,1);z2];
    d2 = A2 \ [sparse(N2,1);z1];
    u1 = u1 + d1;
    u2 = u2 + d2;

    %---Adaptive transmission conditions---%
    iter=iter+1; iter_total=iter_total+1;
    %---Updates---%
    d11= d1(1:N1);
    d22= d2(1:N2);
    d1b= d1(N1+1:end); % difference in iterates between generations
    d2b= d2(N2+1:end);

    u11= u1(1:N1);      % new solution in 1st subdomain, etc.
    u22= u2(1:N2);
    u1b= u1(N1+1:end);
    u2b= u2(N2+1:end);

    z1=-Ab1*d11 + T1*d1b;
    z2=-Ab2*d22 + T2*d2b;

%     %---Visual progress---%
%     figure(1)
%     u=[u11;(u1b+u2b)/2;u22];
%     surf(reshape(u,sqrt(N),sqrt(N)))
%     pause(0)

    %~~~Convergence behaviour~~~%
    error=[error, norm(u_control - [u11;(u1b+u2b)/2;u22])];
    %~~~%
end
u=[u11;(u1b+u2b)/2;u22];