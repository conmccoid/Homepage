%=== EX_AOSMConv===%
% example to compare convergence behaviour, using ALGO files as
% subfunctions

clear

%---Set-up---%
N=100^2;
N1=49*100; N2=50*100;
M=N-N1-N2;

[A,ind,T1,T2]=MAT_AOSMTestSuite_Laplace_v1_20230221(N); % matrix of the problem
f=ones(N,1); f(ind)=1;  % RHS
u_control=A \ f;        % 'exact' solution

u10=zeros(N1+M,1); u20=zeros(N2+M,1);
% u10=rand(N1+M,1); u20=rand(N2+M,1);

%% ITCs: Robin
[u_std,T1_std,T2_std,err_std_R]=ALGO_fparaAOSM_std(A,N1,N2,f,eps,M-1,T1,T2,u10,u20);
[u_pc, T1_pc, T2_pc, err_pc_R ]=ALGO_fparaAOSM_pc( A,N1,N2,f,eps,20,T1,T2,u10,u20);
[u_pcw,T1_pcw,T2_pcw,err_pcw_R]=ALGO_fparaAOSM_w(  A,N1,N2,f,eps,M-1,T1,T2,u10,u20);
[u_fom,T1_fom,T2_fom,err_fom_R]=ALGO_fparaAOSM_FOM(A,N1,N2,f,eps,M-1,T1,T2,u10,u20);
[u_sm, ~,~,err_sm_R]=ALGO_SM_pc(A,N1,N2,f,eps,M-1,T1,T2);
[u_gmr,~,~,err_gmr_R]=ALGO_fparaGMRES(A,N1,N2,f,eps,M-1,T1,T2);

%% ITCs: Dirichlet
T1=sparse(M,M); T2=sparse(M,M);

[u_std,T1_std,T2_std,err_std_D]=ALGO_fparaAOSM_std(A,N1,N2,f,eps,M-1,T1,T2,u10,u20);
[u_pc, T1_pc, T2_pc, err_pc_D ]=ALGO_fparaAOSM_pc( A,N1,N2,f,eps,M-1,T1,T2,u10,u20);
[u_pcw,T1_pcw,T2_pcw,err_pcw_D]=ALGO_fparaAOSM_w(  A,N1,N2,f,eps,M-1,T1,T2,u10,u20);
[u_fom,T1_fom,T2_fom,err_fom_D]=ALGO_fparaAOSM_FOM(A,N1,N2,f,eps,M-1,T1,T2,u10,u20);
[u_sm, ~,~,err_sm_D]=ALGO_SM_pc(A,N1,N2,f,eps,M-1,T1,T2);
[u_gmr,~,~,err_gmr_D]=ALGO_fparaGMRES(A,N1,N2,f,eps,M-1,T1,T2);

%% Figure
figure(1)
semilogy(1:length(err_std_R),err_std_R,'k.--',...
    1:length(err_pc_R),err_pc_R,'ko--',...
    1:length(err_pcw_R),err_pcw_R,'k*--',...
    1:length(err_fom_R),err_fom_R,'k^--',...
    1:length(err_sm_R),err_sm_R,'k-',...
    1:length(err_gmr_R),err_gmr_R,'k.-.',...
    1:length(err_std_D),err_std_D,'r.--',...
    1:length(err_pc_D),err_pc_D,'ro--',...
    1:length(err_pcw_D),err_pcw_D,'r*--',...
    1:length(err_fom_D),err_fom_D,'r^--',...
    1:length(err_sm_D),err_sm_D,'r-',...
    1:length(err_gmr_D),err_gmr_D,'r.-.',...
    'markersize',10,'linewidth',2)
xlabel('Iteration')
ylabel('2-norm of error')
legend('Standard - Robin','Corrector - Robin','Woodbury - Robin','FOM - Robin','OSM - Robin','GMRES - Robin',...
    'Standard - Dirichlet','Corrector - Dirichlet','Woodbury - Dirichlet','FOM - Dirichlet','OSM - Dirichlet','GMRES - Dirichlet')
axis([1,M,1e-15,1e5])
set(gca,'fontsize',20,'linewidth',2)