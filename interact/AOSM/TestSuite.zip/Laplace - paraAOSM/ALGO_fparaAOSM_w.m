function [u,T1,T2,error] = ALGO_fparaAOSM_w(A,N1,N2,f,tol,itermax,T1,T2,u10,u20)
% fparaAOSM_w runs the fully parallel AOSM in a corrector
% formulation with the Woodbury update

%===Problem setup: constant components===%
N=length(A);    % size of full system
M=N-N1-N2;      % size of transmission boundary
%---Matrix blocks---% (b is for boundary)
A11=A(1:N1,1:N1);      % top left block, interior of 1st subdomain
A1b=A(1:N1,N1+1:N1+M); % top middle block, boundary contribution 
A10=A(1:N1,N1+M+1:end);% top right block, ideally zero
Ab1=A(N1+(1:M),1:N1);      % middle left block, 1st domain on boundary
Abb=A(N1+(1:M),N1+(1:M));  % central block, interface conditions
Ab2=A(N1+(1:M),N1+M+1:end);% middle right block, 2nd domain on boundary
A22=A(N1+M+1:end,N1+M+1:end);% bottom right block, int of 2nd subdomain
A2b=A(N1+M+1:end,N1+(1:M));  % bottom middle block, boundary contribution
A20=A(N1+M+1:end,1:N1);      % bottom left block, ideally zero
if nnz(A10)>0 || nnz(A20)>0 % checking appropriate zeros in subdivision
    disp('Subdivision not allowed: nonzero elements in corner blocks')
end
f1=f(1:N1); fb=f(N1+(1:M)); f2=f(N1+M+1:end);               % RHS, constant parts

%===Initialization: first choices of u's and T's===%
%---u's---%
u11=u10(1:N1);           % solution on 1st subdomain
u1b=u10(N1+1:end);       % solution on interface of 1st subdomain
u22=u20(1:N2);           % solution on 2nd subdomain
u2b=u20(N2+1:end);       % solution on interface of 2nd subdomain
%---A's---%
A1=[A11,A1b;Ab1,Abb+T2]; A2=[A22,A2b;Ab2,Abb+T1]; % subdomain matrices

%---Empty W and V matrices---%
W1b=zeros(M); W2b=W1b; V1=W1b; V2=V1;
W11=zeros(N1,M); W22=zeros(N2,M);
H1=zeros(M); H2=zeros(M);
Z1=zeros(N1+M,M); Z2=zeros(N2+M,M);
invB1=[]; invB2=[];

%---First run---%        % to seed the Krylov subspaces
z1 = -Ab1*u11 + T1*u1b;  % RHS for 2nd subdomain
z2 = -Ab2*u22 + T2*u2b;  % RHS for 1st subdomain
u1 = A1 \ [f1;fb+z2];    % soln on 1st subdomain
u2 = A2 \ [f2;fb+z1];    % soln on 2nd subdomain
d1 = u1 - u10;        % difference between soln iterates
d2 = u2 - u20;
udb= u1(N1+1:end)-u2(N2+1:end);

w11= d1(1:N1);           % initialization of 1st Krylov subspace
w1b= d1(N1+1:end);
a1 = norm(w1b); H1(1,1)=a1;
w1b=w1b/a1; W1b(:,1)=w1b;
w11=w11/a1; W11(:,1)=w11;
v1 = -Ab1*w11 + T1*w1b; V1(:,1)=v1;

w22= d2(1:N2);           % initialization of 2nd Krylov subspace
w2b= d2(N2+1:end);
a2 = norm(w2b); H2(1,1)=a2;
w2b=w2b/a2; W2b(:,1)=w2b;
w22=w22/a2; W22(:,1)=w22;
v2 = -Ab2*w22 + T2*w2b; V2(:,1)=v2;

%~~~Convergence behaviour~~~%
u_control = A \ f;       % exact soln
u=zeros(N1+M+N2,1);
u(1:N1)=u1(1:N1);        % current numerical soln
u(N1+(1:M))=(u1(N1+1:end)+u2(N2+1:end))/2;
u(N1+M+1:end)=u2(1:N2);
error=norm(u_control - u); % init error
%~~~%

%---Iteration count---%
iter=2; i=2;             % in this case, i and iter are equal throughout

%===Iterations===%
while norm(d1)+norm(d2)>tol && iter<=itermax
    %---Solves---%
    z1 = A1 \ [sparse(N1,1);v2]; z1b=z1(N1+1:end); Z1(:,i-1)=z1;
    z2 = A2 \ [sparse(N2,1);v1]; z2b=z2(N2+1:end); Z2(:,i-1)=z2;

    %---Schur Shuffle---%
    s  = -W2b(:,1:i-2)'*z1b;
    t  = -Z1(N1+1:end,1:i-2)'*w2b;
    b  = 1 - w2b'*z1b;
    invB2= SUB_altAOSM_SchurShuffle_v1_20230227(invB2,s,t,b);
    s  = -W1b(:,1:i-2)'*z2b;
    t  = -Z2(N2+1:end,1:i-2)'*w1b;
    b  = 1 - w1b'*z2b;
    invB1= SUB_altAOSM_SchurShuffle_v1_20230227(invB1,s,t,b);

    %---Woodbury matrix identity---%
    d1 = (a2+w2b'*udb)*(z1 + Z1(:,1:i-1)*invB2*W2b(:,1:i-1)'*z1b);
    d2 = (a1-w1b'*udb)*(z2 + Z2(:,1:i-1)*invB1*W1b(:,1:i-1)'*z2b);
    u1 = u1 + d1;
    u2 = u2 + d2;

    %---MGS---%
    w11= d1(1:N1); w1b= d1(N1+1:end);
    w22= d2(1:N2); w2b= d2(N2+1:end);
    udb= udb+w1b-w2b;
    for k=1:i-1
        h1=W1b(:,k)'*w1b; H1(k,i)=h1;
        w1b=w1b-h1*W1b(:,k);
        w11=w11-h1*W11(:,k);
        h2=W2b(:,k)'*w2b; H2(k,i)=h2;
        w2b=w2b-h2*W2b(:,k);
        w22=w22-h2*W22(:,k);
    end
    a1=norm(w1b); H1(i,i)=a1;
    w1b=w1b/a1; W1b(:,i)=w1b;
    w11=w11/a1; W11(:,i)=w11;
    v1=-Ab1*w11 + T1*w1b; V1(:,i)=v1;
    a2=norm(w2b); H2(i,i)=a2;
    w2b=w2b/a2; W2b(:,i)=w2b;
    w22=w22/a2; W22(:,i)=w22;
    v2=-Ab2*w22 + T2*w2b; V2(:,i)=v2;

    %---Updates---%
    i=i+1;
    iter=iter+1;
    u(1:N1)=u1(1:N1);
    u(N1+(1:M))=(u1(N1+1:end)+u2(N2+1:end))/2;
    u(N1+M+1:end)=u2(1:N2);

    %~~~Convergence behaviour~~~%
    error=[error, norm(u_control - u)];
    %~~~%
end
T1=T1 - V1*W1b';
T2=T2 - V2*W2b';