function invB_new = SUB_altAOSM_SchurShuffle_v1_20230227(invB,s,t,b)
% SCHURSHUFFLE finds inverse of matrix when inverse of principal submatrix
% is known
% invB_new = SchurShuffle(invB,s,t,b) calculates the inverse of the
% matrix [B,s;t',b] where B is an invertible matrix with inverse invB, s
% and t are vectors of equal length, and b is a scalar.

if isempty(invB)
    % special first case
    invB_new = 1/b;
else
    v = invB*s;
    u = t'*invB;
    d = b - t'*v;
    invB_new = [invB + v*u/d, -v/d;
                        -u/d,  1/d];
end
end