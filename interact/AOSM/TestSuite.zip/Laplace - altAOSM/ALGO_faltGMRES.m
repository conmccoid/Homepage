function [u,T1,T2,error] = ALGO_faltGMRES(A,N1,N2,f,tol,itermax,T1,T2)
% runs GMRES applied to multiplicative Schwarz

% This algorithm requires an optimization step to find updates to
% solutions. This is because the transmission conditions update at every
% step, meaning manually keeping track of solutions requires additional
% solves related to the updates to the T matrices.

%===Problem setup: constant components===%
N=length(A);    % size of full system
M=N-N1-N2;      % size of transmission boundary
%---Matrix blocks---% (b is for boundary)
A11=A(1:N1,1:N1);      % top left block, interior of 1st subdomain
A1b=A(1:N1,N1+1:N1+M); % top middle block, boundary contribution 
A10=A(1:N1,N1+M+1:end);% top right block, ideally zero
Ab1=A(N1+(1:M),1:N1);      % middle left block, 1st domain on boundary
Abb=A(N1+(1:M),N1+(1:M));  % central block, interface conditions
Ab2=A(N1+(1:M),N1+M+1:end);% middle right block, 2nd domain on boundary
A22=A(N1+M+1:end,N1+M+1:end);% bottom right block, int of 2nd subdomain
A2b=A(N1+M+1:end,N1+(1:M));  % bottom middle block, boundary contribution
A20=A(N1+M+1:end,1:N1);      % bottom left block, ideally zero
if nnz(A10)>0 || nnz(A20)>0 % checking appropriate zeros in subdivision
    disp('Subdivision not allowed: nonzero elements in corner blocks')
end
f1=f(1:N1); fb=f(N1+(1:M)); f2=f(N1+M+1:end);               % RHS, constant parts

%===Initialization===%
%---A's---%
A1=[A11,A1b;Ab1,Abb+T2]; A2=[A22,A2b;Ab2,Abb+T1]; % subdomain matrices
%---System---%
fK=[f1;fb] + [sparse(N1,N2+M);-Ab2,T2]*( A2 \ [f2;fb]); fK = A1 \ fK;
A_gmr= eye(N1+M) - (A1 \ ( [sparse(N1,N2+M);-Ab2,T2] * ( A2 \ [sparse(N2,N1+M);-Ab1,T1])));

[u1,~,~,~,error]=gmres(A_gmr,fK,[],tol,itermax);
u2 = A2 \ ([f2;fb] + [sparse(N2,N1+M);-Ab1,T1]*u1);
u = [u1(1:N1); (u1(N1+1:end)+u2(N2+1:end))/2; u2(1:N2)];

%~~~Convergence behaviour~~~%
u_control = A \ f;
error=[error;norm(u_control - u)];
end