function [u,T1,T2,error] = ALGO_faltAOSM_std(A,N1,N2,f,tol,itermax,T1,T2,u10)
% faltAOSM_std runs the fully alternating AOSM with "standard" progression

%===Problem setup: constant components===%
N=length(A);    % size of full system
M=N-N1-N2;      % size of transmission boundary
%---Matrix blocks---% (b is for boundary)
A11=A(1:N1,1:N1);      % top left block, interior of 1st subdomain
A1b=A(1:N1,N1+1:N1+M); % top middle block, boundary contribution 
A10=A(1:N1,N1+M+1:end);% top right block, ideally zero
Ab1=A(N1+(1:M),1:N1);      % middle left block, 1st domain on boundary
Abb=A(N1+(1:M),N1+(1:M));  % central block, interface conditions
Ab2=A(N1+(1:M),N1+M+1:end);% middle right block, 2nd domain on boundary
A22=A(N1+M+1:end,N1+M+1:end);% bottom right block, int of 2nd subdomain
A2b=A(N1+M+1:end,N1+(1:M));  % bottom middle block, boundary contribution
A20=A(N1+M+1:end,1:N1);      % bottom left block, ideally zero
if nnz(A10)>0 || nnz(A20)>0 % checking appropriate zeros in subdivision
    disp('Subdivision not allowed: nonzero elements in corner blocks')
end
f1=f(1:N1); fb=f(N1+(1:M)); f2=f(N1+M+1:end);               % RHS, constant parts

%===Initialization: first choices of u's and T's===%
%---u's---%
u11=u10(1:N1);           % solution on 1st subdomain
u1b=u10(N1+1:end);       % solution on interface of 1st subdomain
u1_old=u10;
%---A's---%
A1=[A11,A1b;Ab1,Abb+T2]; A2=[A22,A2b;Ab2,Abb+T1]; % subdomain matrices

%---Empty W and V matrices---%
W1b=zeros(M); W2b=W1b; V1=W1b; V2=V1;
W11=zeros(N1,M); W22=zeros(N2,M);
H1=zeros(M); H2=zeros(M);

%---First run---%
z1 = -Ab1*u11 + T1*u1b;
u2 = A2 \ [f2;fb+z1];
u22= u2(1:N2);
u2b= u2(N2+1:end);
u2_old = u2;
z2= -Ab2*u22 + T2*u2b;
u1 = A1 \ [f1;fb+z2];
u11= u1(1:N1);
u1b= u1(N1+1:end);
d1 = u1 - u1_old;
u1_old = u1;

%---Update previous solutions---%
u=zeros(N,1);
u(1:N1+M)= u1;      % new solution in 1st subdomain, etc.
u(N1+M+1:end)=u2(1:N2);
%~~~Convergence behaviour~~~%
u_control = A \ f;
error=norm(u_control - u);
%~~~%

w11= d1(1:N1);
w1b= d1(N1+1:end);
a1 = norm(w1b); w1b=w1b/a1; w11=w11/a1;
W1b(:,1)=w1b; W11(:,1)=w11;
v1 = -Ab1*w11 + T1*w1b;
V1(:,1)=v1;
H1(1,1)=a1;

z1 = -Ab1*u11 + T1*u1b - V1(:,1)*W1b(:,1)'*u1b;
u2 = [A22,A2b;Ab2,Abb+T1-V1(:,1)*W1b(:,1)'] \ [f2;fb+z1];
u22= u2(1:N2);
u2b= u2(N2+1:end);
d2 = u2 - u2_old;
u2_old = u2;

w22= d2(1:N2);
w2b= d2(N2+1:end);
a2 = norm(w2b); w2b=w2b/a2; w22=w22/a2;
W2b(:,1)=w2b; W22(:,1)=w22;
v2 = -Ab2*w22 + T2*w2b;
V2(:,1)=v2;
H2(1,1)=a2;

%~~~Convergence behaviour~~~%
u(N1+M+1:end)=u2(1:N2);
error=[error,norm(u_control - u)];
%~~~%

%---iteration count---%
iter=2; i1=2; i2=2; iter_total=3;

%===Iterations===%
while norm(d1)>tol && iter_total<=itermax
    %---Adaptive transmission conditions---%
    iter=iter+1; iter_total=iter_total+1;
    if mod(iter,2)==1 % alternating approach: update only every second iteration
        %---Solve---%
        z2 = -Ab2*u22 + T2*u2b - V2(:,1:i2-1)*W2b(:,1:i2-1)'*u2b;
        u1 = [A11,A1b;Ab1,Abb+T2-V2(:,1:i2-1)*W2b(:,1:i2-1)'] \ [f1;fb+z2];
        u11= u1(1:N1);
        u1b= u1(N1+1:end);
        d1 = u1 - u1_old;
        u1_old = u1;

        %---MGS---%
        w11= d1(1:N1);
        w1b= d1(N1+1:end);
        for k=1:i1-1
            h1=W1b(:,k)'*w1b;
            w1b=w1b-h1*W1b(:,k);
            w11=w11-h1*W11(:,k);
            H1(k,i1)=h1;
        end
        a1=norm(w1b); H1(i1,i1)=a1;
        w1b=w1b/a1; W1b(:,i1)=w1b;
        w11=w11/a1; W11(:,i1)=w11;
        v1=-Ab1*w11 + T1*w1b; V1(:,i1)=v1;
        
        %---Updates---%
        i1=i1+1;
        u(1:N1+M)=u1;
    else
        %---Solve---%
        z1 = -Ab1*u11 + T1*u1b - V1(:,1:i1-1)*W1b(:,1:i1-1)'*u1b;
        u2 = [A22,A2b;Ab2,Abb+T1-V1(:,1:i1-1)*W1b(:,1:i1-1)'] \ [f2;fb+z1];
        u22= u2(1:N2);
        u2b= u2(N2+1:end);
        d2 = u2 - u2_old;
        u2_old = u2;

        %---MGS---%
        w22= d2(1:N2);
        w2b= d2(N2+1:end);
        for k=1:i2-1
            h2=W2b(:,k)'*w2b;
            w2b=w2b-h2*W2b(:,k);
            w22=w22-h2*W22(:,k);
            H2(k,i2)=h2;
        end
        a2=norm(w2b); H2(i2,i2)=a2;
        w2b=w2b/a2; W2b(:,i2)=w2b;
        w22=w22/a2; W22(:,i2)=w22;
        v2=-Ab2*w22 + T2*w2b; V2(:,i2)=v2;
        
        %---Updates---%
        i2=i2+1;
        u(N1+M+1:end)=u2(1:N2);
        u(N1+(1:M))=u2(N2+1:end);
    end

%     %---Visual progress---%
%     figure(1)
%     surf(reshape(u,sqrt(N),sqrt(N)))
%     pause(0)

    %~~~Convergence behaviour~~~%
    error=[error, norm(u_control - u)];
    %~~~%
end
T1=T1 - V1*W1b';
T2=T2 - V2*W2b';