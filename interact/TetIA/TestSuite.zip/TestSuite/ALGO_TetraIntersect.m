function [P,n] = ALGO_TetraIntersect(V,U)
% TETRAINTERSECT calculates the intersection between two tetrahedra
%   [P,n]=TetraIntersect(V,U) calculates the vertices of the polyhedron of
%   intersection (stored in P) between the subject tetrahedron V and the
%   clipping tetrahedron U. Neighbours of V that may also intersect U are
%   listed in n.

%   Usage notes:
%       -- The output n gives the neighbours of V listed in combinadic
%       ranking order. That is, the first entry of n corresponds to the
%       neighbour of V that shares its face between the 1st, 2nd and 3rd
%       listed vertices. The matrix Kmap found within this code identifies
%       the remaining listing.
%       When listing neighbours in a triangulation, either keep combinadic
%       ordering or take note of how this ordering has been permuted and
%       apply the reverse permutation to the output n.
%
%       -- Three optional sections have been included to guard against the
%       most pathological of cases. They may be removed if the vertices of
%       U do not approach the edges of V and vice versa.
%
%       -- The two subfunctions that perform the intersection calculations
%       are not essential to the algorithm. They may be replaced at will
%       with other intersection calculations.

% Desired improvements
%   Better intersection formulas
%   Streamlining parentage issue
%   Pre-allocating size to P

%===Change of Coordinates===%
v0=V(:,1);
A=V(:,2:4)-v0; X=A\(U-v0);
X=[1-sum(X,1);X];   % barycentric coord.s of U
sX=X>=0;            % signs of barycentric coordinates
% each coord. has a paired vertex of Y, specifically that vertex that is
% opposite the plane p=0
% coord. i -> V(:,i) lies where this coord. is equal to 1
% ref. planes are numbered for their coord.s, not their vertices
% so the 1st ref. plane is where coord. 1 is zero, and therefore does not
% contain V(:,1)

%---Test null intersection---%
n=zeros(1,4);   % nhbrs of U that also intersect V
if prod(sum(sX,2))==0
    P=[];
    return
end
P=U(:,prod(sX)==1); % vertices of U in V

%===Intersections between edges of X and faces of Y===%
%---Initialization---%
S1=false(4,6);      % indicators of intersections (# faces of V x # possible intersections)
jmap=[1,1,2,1,2,3;  % ordering of edges (must match listing in triangulation)
      2,3,3,4,4,4]; % combinadic ranking is used throughout for consistency

%---Determine which intersections occur---%
for i=1:4                       % for each ref. plane
    for j=1:6                   % for each pair of vertices of X
        j1=jmap(1,j); j2=jmap(2,j); % vertices of this pair
        if sX(i,j1)~=sX(i,j2)   % determine if they intersect
            S1(i,j)=true;
        end
    end
end

%---Determine signs of intersections---%
sQ=false(4,6,4);                % signs of intersections (# faces of Y x # edges of X x # coord.s)
Q=zeros(4,6,4);                 % intersection coord.s (# coord.s x # int.s x # faces)
indi=1:4;
for j=1:6                       % for each pair of vertices (edge of X)
    j1=jmap(1,j); j2=jmap(2,j); % pair of vertices
    flagQ=false(4,4);           % flags for known signs (# planes x # coords.)
    flagSLP=sum(S1(:,j))>2;     % check if the straight line principle can be applied to this edge of X
    for i=indi(S1(:,j))         % for each ref. plane with an intersection
        indk=indi(indi~=i);     % don't need to look at coord. assoc. w/ plane i
        sQ(i,j,i)=true;         % coord. assoc. w/ plane i is zero and therefore positive
        for k=indk              % for each remaining coord.
            if ~S1(k,j)             % no int. for this edge of X in k direction
                sQ(i,j,k)=sX(k,j1); % inherited sign
                flagQ(i,k)=true;    % sign now known
            elseif flagQ(k,i)       % paired sign is already known
                sQ(i,j,k)=~xor(sQ(k,j,i),~xor(sX(i,j1),sX(k,j2)));
                flagQ(i,k)=true;    % sign now known
            elseif ~flagQ(i,k)      % check if sign has been found through another mean (exclusively straight line principle)
                q=EdgeIntersect(X([i,k],j1),X([i,k],j2)); % calc. coord.
                Q(k,j,i)=q;         % store coord.
                sQ(i,j,k)=q>=0;     % determine sign directly
                flagQ(i,k)=true;    % sign now known
            end
        end
        if prod(sQ(i,j,:))==1   % all coord.s positive
            for k=indk(indk~=1) % for all coord.s (except zeroth coord.)
                if Q(k,j,i)==0  % this coord. not yet calculated
                    Q(k,j,i)=EdgeIntersect(X([i,k],j1),X([i,k],j2));
                end
            end
            P=[P, v0+A*Q(2:end,j,i)]; % add this int. to P
            n(5-i)=1;                 % nhbrs of V that also intersect U
        end
        %---OPTIONAL SECTION: Straight line principle, checked for each plane---%
        if flagSLP                      % if there are enough int.s for this edge of X
            diff1=xor(permute(sQ(i,j,indk),[3,2,1]),sX(indk,j1)); % find which coord.s have different signs from the 1st vertex of X
            diff2=xor(permute(sQ(i,j,indk),[3,2,1]),sX(indk,j2)); % same, but for 2nd vertex of X on this edge
            if sum(diff1)==1            % if there is 1 int. between this int. and the 1st vertex
                ind_diff=indk(~diff1);  % for those coord.s which differ
                k=indk(diff1);          % for the plane that causes the different sign
                sQ(k,j,ind_diff)=sQ(i,j,ind_diff);  % fill in the signs for the intermediary int.
                flagQ(k,ind_diff)=true;             % flag that we now know them
            elseif sum(diff2)==1        % otherwise, if there is 1 int. between this int. and the 2nd vertex
                ind_diff=indk(~diff2);
                k=indk(diff2);
                sQ(k,j,ind_diff)=sQ(i,j,ind_diff);  % fill in the signs for the intermediary int.
                flagQ(k,ind_diff)=true;             % flag that we now know them
            end
        end
        %---END OPTIONAL SECTION---%
    end
end

%===Intersections between faces of X and edges of Y===%

%---Determine which intersections occur---%
S2=false(6,4);                          % indicators for intersections (# edges of Y x # faces of X)
Imap=[0,1,2,4;1,0,3,5;2,3,0,6;4,5,6,0]; % combinadic ranking of two elements
Jmap=[0,1,1,2,2,0; 0,0,1,3,0,3; 0,0,0,0,4,4; 0,0,0,0,2,3; 0,0,0,0,0,4; 0,0,0,0,0,0];
                                        % combinadic ranking of 2-combo.s
Adj=Jmap>0;                             % comb. adj. mat.
Kmap=[1,1,1,2;                          % rank order of 3-combos
      2,2,3,3;
      3,4,4,4];
ind_plane=1:4; ind_plane=ind_plane(sum(S1,2)>0); num_plane=length(ind_plane);
for i1=1:num_plane-1                                % for each plane of Y with an intersection
    plane=ind_plane(i1);
    ind_int=1:6; ind_int=ind_int(S1(plane,:));      % list of intersections on this plane
    for j=ind_int(1:end-1)                           % for each intersection on this plane
        for k=ind_int(Adj(j,S1(plane,:)))             % for each adj. int.
            face=Jmap(j,k);                            % combinadic ranking of face of X containing edges j and k
            for i2=i1+1:num_plane                      % for each barycentric coord. in the plane
                coord=ind_plane(i2);
                edge=Imap(plane,coord);                 % combinadic ranking of this edge of Y
                if sQ(plane,j,coord)~=sQ(plane,k,coord) % if the signs of this coord. of these int.s on this plane are different,
                    S2(edge,face)=true;                  % then there is an int. between this edge of Y and this face of X
                end
            end
        end
    end
end

%---OPTIONAL SECTION: Enforcing convexity subroutine---%
flagConv=false(6,1);
for edge=1:6
    if sum(S2(edge,:))>2
        disp('Convexity failure!')
        adj_edges=1:6; adj_edges=adj_edges(Adj(edge,:));
        S2(adj_edges,:)=true;
        flagConv(edge)=true;
    end
end
%---END OPTIONAL SECTION---%

%---Determine signs of intersections---%
sR=false(4,6,4);                % signs of int.s (# coord.s x # edges of Y x # faces of X)
R=zeros(4,6,4);                 % int. coord.s   (# coord.s x # edges of Y x # faces of X)
flagR=false(4,6,4);             % flagged signs  (# coord.s x # edges of Y x # faces of X)
ind_face=1:4; ind_face=ind_face(sum(S2,1)>0);
for face=ind_face                           % for each face of X with an int.
    ind_edge=1:6; ind_edge=ind_edge(S2(:,face));
    for edge=ind_edge                       % for each edge of Y intersecting this face of X
        i1=jmap(1,edge); i2=jmap(2,edge);   % unrank this edge
        sR([i1,i2],edge,face)=true;         % those coord.s that are necessarily zero are considered inside Y
        ind_coord=setdiff(1:4,[i1,i2]);
        for coord=ind_coord                 % for each remaining coord.
            k1=Imap(i1,coord);              % one of the adj. edges of Y wrt. this coord.
            k2=Imap(i2,coord);              % the other one
            if ~S2(k1,face)                 % if there is no int. with this adj. edge
                                            % then the sign of this coord. is inherited
                [parent,~]=Parents(face,i1,S1,Jmap);
                sR(coord,edge,face)=sQ(i1,parent,coord);
            elseif ~S2(k2,face)
                [parent,~]=Parents(face,i2,S1,Jmap);
                sR(coord,edge,face)=sQ(i2,parent,coord);
            elseif flagR(i2,k1,face)        % if the sign of this coord. has been found on the adj. edge
                                            % then Cor. 1 applies
                [parent1,parent2]=Parents(face,i1,S1,Jmap);
                sR(coord,edge,face)=~xor(sR(i2,k1,face),~xor(sQ(i1,parent1,coord),sQ(i1,parent2,i2)));
            elseif flagR(i1,k2,face)        % same for other adj. edge
                [parent1,parent2]=Parents(face,i2,S1,Jmap);
                sR(coord,edge,face)=~xor(sR(i1,k2,face),~xor(sQ(i2,parent1,coord),sQ(i2,parent2,i1)));
            else
                r=FaceIntersect(X([coord;i1;i2],Kmap(:,face))); % calc. coord.
                R(coord,edge,face)=r;                           % store coord.
                sR(coord,edge,face)=r>=0;                       % sign of coord.
                flagR(coord,edge,face)=true;                    % flag that coord. was calculated
            end
        end
        if prod(sR(:,edge,face))==1             % if int. lies in Y
            for coord=ind_coord(ind_coord~=1)   % find remaining coord.s not calculated
                if ~flagR(coord,edge,face)
                    r=FaceIntersect(X([coord;i1;i2],Kmap(:,face))); % calc. coord.
                else
                    r=R(coord,edge,face);
                end
                if r>1
                    R(coord,edge,face)=1;
                    R(ind_coord(ind_coord~=coord),edge,face)=0;
                elseif r<0
                    R(coord,edge,face)=0;
                    R(ind_coord(ind_coord~=coord),edge,face)=1;
                else
                    R(coord,edge,face)=r;
                end
            end
            P=[P, v0+A*R(2:end,edge,face)];     % add int. to P
            n(5-[i1,i2])=1;                     % nhbrs update
        end
    end
end

%===Vertices of V in U===%
%---Determine intersections in same way---%
indV=false(4,1);                % indicators for vertices of V
Vmap=[6,2;6,1;1,4;1,3];         % edge/coord. combos of Y for each vertex of V
% other options for Vmap (can swap individual lines in and out):
% [3,4;2,4;4,2;2,2], [5,3;4,3;5,1;3,1]
for vertex=1:4                       % for each vertex of V
    edge=Vmap(vertex,1);             % pick an edge of Y that passes through this vertex
    coord=Vmap(vertex,2);            % pick the coord. that corresponds to this vertex on this edge
    indj=1:4; indj=indj(S2(edge,:)); % pick out faces of X that intersect this edge of Y
    if ~isempty(indj) && sR(coord,edge,indj(1))~=sR(coord,edge,indj(2)) % if int.s lie on opposite sides of vertex
        indV(vertex)=true;
    end
    %---OPTIONAL SECTION: Enforcing convexity subroutine---%
    if flagConv(edge) && prod(sR(vertex,edge,:))==0 && sum(sR(vertex,edge,:))>0
        indV(vertex)=true;
    end
    %---END OPTIONAL SECTION---%
end
P=[P,V(:,indV)];                % add vertices to P
if sum(indV)>2                  % if three or more interior points
    n=[1 1 1 1];                % all neighbours of V intersect with U
end

%===Clean-up and visualization===%
P=SortAndRemoveDoubles(P);
% PLOT_PatchPolyhedron_v1_20201105(P)
% pause(0)
end

%===Intersection formulas===%
% these subfunctions can be exchanged for other formulae with higher
% accuracy

function q=EdgeIntersect(x,y)
% computes intersection q along edge p=0 for edge between x and y
q=(x(1)*y(2) - x(2)*y(1))/(x(1)-y(1));
end

function r=FaceIntersect(X)
% computes intersection r between face lying between vertices x, y and z
% and two coordinates p,q=0
r=det(X)/det([1,1,1;X([2,3],:)]);
end

function [j,k]=Parents(face,plane,S1,Jmap)
% finds the parents of a given face of X from a given plane of Y

% this seems a complicated process to find the parents of
% the face of X, and an alternative should be found
list_ints=1:6; list_ints=list_ints(S1(plane,:));
for parent1=1:length(list_ints)-1
    for parent2=parent1+1:length(list_ints)
        if Jmap(list_ints(parent1),list_ints(parent2))==face
            j=list_ints(parent1);
            k=list_ints(parent2);
        end
    end
end
end