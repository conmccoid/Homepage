===Test Suite for Tetrahedral Intersection Algorithm===

This folder contains MATLAB implementations of the main algorithm and subroutines for
the tetrahedral intersection algorithm, as well as the necessary code to run the
numerical example presented in the article.

Algorithms:
--ALGO_TetraIntersect.m : main algorithm
--ALGO_SutherlandHodgman.m : an implementation of the Sutherland-Hodgman algorithm, used
    for comparison
--Intersection3d.m : intersection algorithm of PANG-3D

Example:
--EX_3DAcc.m : runs the numerical example

Plotting functions:
--ang3d.m : plots an angle arc (original author: Husam Aldahiyat, October, 2008)
--PLOT_PatchPolyhedron.m : colours a polyhedron in 3D space using the patch function
--PLOT_TetraMesh.m : plots tetrahedral meshes

Subroutines:
--SortAndRemoveDoubles.m : sorts points of a polyhedron and removes any doubles
--SUB_Neighbours.m : orders the list of neighbours to match specific use case
--SUB_RemoveDoubles.m : removes doubles of points of a polyhedron