function [P,n]=ALGO_SutherlandHodgman(V,U)
% runs the Sutherland-Hodgman algorithm to calculate the intersection
% between tetrahedra V and U

%===Change of Coordinates===%
v0=V(:,1); %v1=V(:,2)-v0; v2=V(:,3)-v0; v3=V(:,4)-v0;
A=V(:,2:4)-v0; X=A\(U-v0);
X=[1-sum(X,1);X]; % barycentric coord.s of U
sX=X>=0;            % signs of coord.s of X

for plane=1:4
%     if sum(X(plane,:))==0
%         P=[];
%         n=zeros(1,4);
%         return
%     end
    Xp=X(:,sX(plane,:));    % those vertices on the positive side of the plane
    Xn=X(:,~sX(plane,:));   % those vertices on the negative side of the plane
    Np=size(Xp,2);          % number of positive vertices
    Nn=size(Xn,2);          % number of negative vertices
    Q=zeros(4,Np*Nn);       % initialize intersections
    for i=1:Np
        for j=1:Nn
            ind=i + (j-1)*Np;
            for coord=setdiff(1:4,plane)
                Q(coord,ind)=(Xp(coord,i)*Xn(plane,j) - Xp(plane,i)*Xn(coord,j))/(Xn(plane,j)-Xp(plane,i));
            end
        end
    end
    X=[Xp,Q];
    sX=X>=0;
end

P=v0 + A*X(2:end,:);
n=ones(1,4);
end